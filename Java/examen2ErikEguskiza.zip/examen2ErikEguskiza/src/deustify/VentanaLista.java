package deustify;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class VentanaLista extends JFrame {
	protected Lista lista;
	protected JButton botonAnadir;
	protected JButton botonBorrar;
	protected JButton botonModificar;
	protected JButton botonGuardar;
	protected JButton botonCargar;
	protected JComboBox<Cancion> comboCanciones;
	
	public VentanaLista(Lista lista) {
		this.lista = lista;
		
		JPanel panelBotones = new JPanel();
		
		botonAnadir = new JButton("Añadir");
		botonBorrar = new JButton("Borrar");
		botonModificar = new JButton("Modificar");
		botonGuardar = new JButton("Guardar");
		botonCargar = new JButton("Cargar");
		
		panelBotones.add(botonAnadir);
		panelBotones.add(botonBorrar);
		panelBotones.add(botonModificar);
		panelBotones.add(botonGuardar);
		panelBotones.add(botonCargar);
		
		botonAnadir.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				Cancion nueva = new Cancion();
				lista.getCanciones().add(nueva);
				comboCanciones.addItem(nueva);
				new VentanaCancion(nueva);
			}
		});
		
		botonBorrar.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TAREA 3: Borra la canción seleccionada de la lista y de comboCanciones
				Cancion cancion = (Cancion) comboCanciones.getSelectedItem();
				lista.borrarCancion(cancion);
				comboCanciones.removeItem(cancion);
				//Hago una llamada a un metodo que he creado ahi parea borrar la cancion seleccionada
			}
		});
		
		botonModificar.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				Cancion seleccionada = (Cancion) comboCanciones.getSelectedItem();
				if (seleccionada != null) {
					VentanaCancion v = new VentanaCancion(seleccionada);
					v.izenburua.setText(seleccionada.getTitulo());
					v.autorea.setText(seleccionada.getAutoria());
					v.linka.setText(seleccionada.getEnlace());
					v.iraunketa.setText("" + seleccionada.getDuracion());
				}
			}
		});
		
		botonGuardar.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				lista.guardarDatos();
			}
		});
		
		botonCargar.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				lista.cargarDatos(); //con esto cargo los datos al el array list
				// TAREA 2: Actualiza comboCanciones con los datos de la lista que acabas de leer
				for (Cancion cancion : lista.getCanciones()) {
					comboCanciones.addItem(cancion);
				}
			}
		});
		
		this.add(panelBotones, BorderLayout.SOUTH);
		
		comboCanciones = new JComboBox<Cancion>();
		
		for (Cancion cancion : lista.getCanciones()) {
			comboCanciones.addItem(cancion);
		}
		
		this.add(comboCanciones, BorderLayout.NORTH);
		
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setTitle("Lista de canciones");
		this.setSize(800, 600);
		this.setVisible(true);
		this.setLocationRelativeTo(null);
	}

}
