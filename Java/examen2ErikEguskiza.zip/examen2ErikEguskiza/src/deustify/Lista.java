package deustify;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;

import javax.swing.JOptionPane;


public class Lista {
	protected ArrayList<Cancion> canciones;

	public Lista(ArrayList<Cancion> canciones) {
		this.canciones = new ArrayList<Cancion>();
		for (Cancion cancion : canciones) {
			this.canciones.add(cancion);
		}
	}
	
	public Lista() {
		this.canciones = new ArrayList<Cancion>();
	}

	public ArrayList<Cancion> getCanciones() {
		return canciones;
	}

	public void setCanciones(ArrayList<Cancion> canciones) {
		this.canciones = new ArrayList<Cancion>();
		for (Cancion cancion : canciones) {
			this.canciones.add(cancion);
		}
	}

	@Override
	public int hashCode() {
		return Objects.hash(canciones);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Lista other = (Lista) obj;
		return Objects.equals(canciones, other.canciones);
	}

	@Override
	public String toString() {
		return "Lista [canciones=" + canciones + "]";
	}
	
	public void cargarDatos() {
		String filename = JOptionPane.showInputDialog("Introduce el nombre del fichero");
		try {
			File archivo = new File("C:\\Users\\e.eguskiza\\Downloads\\deustify\\ficheros", filename);
			FileReader lector = new FileReader(archivo);
			BufferedReader bufferedReader = new BufferedReader(lector);
			String linea;
			while ((linea = bufferedReader.readLine()) != null) {
				String[] datos = linea.split(",");
				String titulo = datos[0];
				String autoria = datos[1];
				String enlace = datos[2];
				String duracion = datos[4];   
				Cancion nueva = new Cancion(titulo, autoria, enlace, Integer.parseInt(duracion));
				canciones.add(nueva);
				}
		lector.close();
		System.out.println("Datos cargados desde el archivo " + archivo.getAbsolutePath());
		} catch (IOException ex) {
		System.out.println("Error al cargar los datos desde el archivo");
		ex.printStackTrace();
		}
	}
	
	public void guardarDatos() {
		// TAREA 1: Guarda la lista de canciones en el fichero filename
		try {
		String filename = JOptionPane.showInputDialog("Introduce el nombre del fichero");
		File fichero = new File("C:\\Users\\e.eguskiza\\Downloads\\deustify\\ficheros", filename);
		FileWriter escritor = new FileWriter(fichero);
		
		for (Cancion cancion: canciones) {
			escritor.write(cancion.toString() + "\n");
		}
		escritor.close();
		System.out.println("Datos guardados en el archivo " + fichero.getAbsolutePath());
		} catch (IOException ex) { 
        System.out.println("Error al guardar los datos en el archivo");
        ex.printStackTrace();
			}	
		}
	//Metodo para borrar canciones de arraylist
	public void borrarCancion(Cancion cancion) {
		canciones.remove(cancion);
	}
	
}
