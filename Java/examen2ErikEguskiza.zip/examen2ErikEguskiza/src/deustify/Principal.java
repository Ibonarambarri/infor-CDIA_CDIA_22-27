package deustify;

public class Principal {

	public static void main(String[] args) {
		VentanaLista v = new VentanaLista(new Lista());
	}

}
