package deustify;

import java.io.Serializable;
import java.util.Objects;

public class Cancion implements Serializable {
	protected String titulo;
	protected String autoria;
	protected String enlace;
	protected int duracion;
	
	public Cancion(String titulo, String autoria, String enlace, int duracion) {
		this.titulo = titulo;
		this.autoria = autoria;
		this.enlace = enlace;
		this.duracion = duracion;
	}
	
	public Cancion() {
		this.titulo = "";
		this.autoria = "Anónima";
		this.enlace = "https://";
		this.duracion = 0;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getAutoria() {
		return autoria;
	}

	public void setAutoria(String autoria) {
		this.autoria = autoria;
	}

	public String getEnlace() {
		return enlace;
	}

	public void setEnlace(String enlace) {
		this.enlace = enlace;
	}
	
	public int getDuracion() {
		return duracion;
	}

	public void setDuracion(int duracion) {
		this.duracion = duracion;
	}

	@Override
	public int hashCode() {
		return Objects.hash(autoria, titulo);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cancion other = (Cancion) obj;
		return Objects.equals(autoria, other.autoria) &&  Objects.equals(titulo, other.titulo);
	}

	@Override
	public String toString() {
		return "Cancion [titulo=" + titulo + ", autoria=" + autoria + ", enlace=" + enlace + ","+ "duracion=" +","+ duracion;
	}

	
	
}
