package deustify;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.IOException;

public class VentanaCancion extends JFrame {
	protected Cancion cancion;
	protected JLabel titulo, autoria, enlace, duracion;
	protected JTextField izenburua, autorea, linka, iraunketa;
	protected JButton guardar, cancelar;
	protected JPanel panel1, panel2;
	
	public VentanaCancion(Cancion cancion) {
		this.cancion = cancion;
		// TAREA 4: Crea un panel con 4 JLabel y 4 JTextField para mostrar las propiedades de cancion
		// TAREA 4: Añade el panel a la ventana arriba (BorderLayout.NORTH)
		// TAREA 5: Añade un botón de Guardar que actualice las propiedades de cancion con el contenido de los JTextField
		// TAREA 5: Añade el botón de guardar a la ventana abajo (BorderLayout.SOUTH)
		
		panel1 = new JPanel(new GridLayout(8,1));
		panel2 = new JPanel(new FlowLayout());

		titulo = new JLabel("Titulo: ");
		izenburua = new JTextField();
		autoria = new JLabel("Autoria: ");
		autorea = new JTextField();
		enlace = new JLabel("Enlace: ");
		linka = new JTextField();
		duracion = new JLabel("Duración: ");
		iraunketa = new JTextField();
		guardar = new JButton("Guardar");
		cancelar = new JButton("Cancelar");
		
		
		this.setLayout(new BorderLayout());
		
		panel1.add(titulo);
		panel1.add(izenburua);
		panel1.add(autoria);
		panel1.add(autorea);
		panel1.add(enlace);
		panel1.add(linka);
		panel1.add(duracion);
		panel1.add(iraunketa);
		panel2.add(cancelar);
		panel2.add(guardar);
		this.add(panel1, BorderLayout.NORTH);
		this.add(panel2, BorderLayout.SOUTH);
		
		//FUNCIONALIDADDES BOTONES
		guardar.addActionListener(e ->{
			String t = izenburua.getText();
			String a = autorea.getText();
			String l = linka.getText();
			String i = iraunketa.getText();
			cancion.setTitulo(t);
			cancion.setAutoria(a);
			cancion.setEnlace(l);
			try {
				cancion.setDuracion(Integer.parseInt(i));
			}catch (NumberFormatException ex) {
				System.out.println("Error al guardar los datos, no se pueden meter Strings aqui");
				ex.printStackTrace();
			}	
			dispose();
		});
		
		cancelar.addActionListener(e -> {
			dispose();
		});
		
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setTitle("Cancion");
		this.setSize(400, 300);
		this.setVisible(true);
		this.setLocationRelativeTo(null);
	}
}
